#! /bin/bash
###
 # @Author: Athrun
 # @Email: erythron@qq.com
 # @Date: 2021-05-25 09:04:00
 # @LastEditTime: 2021-06-09 16:58:39
 # @description:
###
source /etc/profile
action=$1
json_str=$2
json_str_cut="${json_str#*=}"
# echo $action
# echo "$json_str_cut"
python3 es.py "$action" "$json_str_cut"

