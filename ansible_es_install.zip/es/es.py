'''
Author: Athrun
Email: erythron@qq.com
Date: 2021-06-03 09:21:37
LastEditTime: 2021-06-17 10:09:43
description: now it is null
'''


import json,os
import sys
import subprocess


ansible_host_no_pd = "{ansible_host} ansible_ssh_port={sshport} ansible_ssh_user={super_os_user} ansible_ssh_common_args='-o StrictHostKeyChecking=no' \n"
ansible_host_with_pd = "{ansible_host} ansible_ssh_port={sshport} ansible_ssh_user={super_os_user} ansible_ssh_pass='{super_os_passwd}' ansible_ssh_common_args='-o StrictHostKeyChecking=no' \n"

ALL_IP = []


def FilePath(pwd,file):
    if os.path.exists(pwd):
        pass
    else:
        os.mkdir(pwd)
    return (os.path.join(pwd,file))



def ToAnsibleHostINI(host_lists):
    ansible_host = '[default] \n'
    ansible_host_master = '[master] \n'
    ansible_host_data = '[data] \n'
    global ALL_IP

    for host_info in host_lists:
        ALL_IP.append(host_info['host'])
        if ('node_type' in host_info and host_info['node_type']=='master'):
            if ('super_os_passwd'  not in host_info):
                ansible_host_master += ansible_host_no_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'])
            else:
                ansible_host_master += ansible_host_with_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'], super_os_passwd=host_info['super_os_passwd'])
        elif ('node_type' in host_info and host_info['node_type']=='data'):
            if ('super_os_passwd'  not in host_info):
                ansible_host_data += ansible_host_no_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'])
            else:
                ansible_host_data += ansible_host_with_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'], super_os_passwd=host_info['super_os_passwd'])
        else:
            if ('super_os_passwd'  not in host_info):
                ansible_host += ansible_host_no_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'])
            else:
                ansible_host += ansible_host_with_pd.format(ansible_host=host_info['host'], sshport=host_info['sshport'], super_os_user=host_info['super_os_user'], super_os_passwd=host_info['super_os_passwd'])
    return (ansible_host+ansible_host_master+ansible_host_data)


def Install(hosts,vars,type):
    if type == "1":
        exec = "ansible-playbook es_cluster_install.yml -i {hosts} --extra-vars='@{vars}'".format(hosts=hosts, vars=vars)
        print ("[info], 执行命令: ", exec)
        process_info = subprocess.run(args=exec, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if process_info.returncode == 0:
            print ("[info], 已安装")
            print ("[info], deploy_service_info=",success_info)
            WriteLog(ansible_log, process_info.stdout.decode())
        else:
            WriteLog(ansible_log, process_info.stdout.decode())
            print ('[error], 日志路径: {path}'.format(path=ansible_log))
            exit(1)

    elif type == "0":
        exec = "ansible-playbook es_single_install.yml -i {hosts} --extra-vars='@{vars}'".format(hosts=hosts, vars=vars)
        print ("[info], 执行命令: ", exec)
        # print (success_info)
        process_info = subprocess.run(args=exec, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if process_info.returncode == 0:
            print ("[info], 已安装")
            print ("[info], deploy_service_info=",success_info)
            WriteLog(ansible_log, process_info.stdout.decode())
        else:
            WriteLog(ansible_log, process_info.stdout.decode())
            print ('[error], 日志路径: {path}'.format(path=ansible_log))
            exit(1)
    else:
        print ("[error], 未定义模式")
        exit(1)


def Uninstall(hosts,vars):
    exec = "cd ./ansible-es && ansible-playbook 5_uninstall.yml -i {hosts} --extra-vars='@{vars}'".format(hosts=hosts, vars=vars)
    print ("[info], 执行命令: ", exec)
    process_info = subprocess.run(args=exec, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if process_info.returncode == 0:
        print ('[info], 已卸载')
        WriteLog(ansible_log, process_info.stdout.decode())
    else:
        WriteLog(ansible_log, process_info.stdout.decode())
        print ('[error], 日志路径: {path}'.format(path=ansible_log))
        exit(1)


def Stop(hosts,vars):
    exec = "cd ./ansible-es && ansible-playbook 4_stop.yml -i {hosts} --extra-vars='@{vars}'".format(hosts=hosts, vars=vars)
    print ("[info], 执行命令: ", exec)
    process_info = subprocess.run(args=exec, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if process_info.returncode == 0:
        print ('[info], 已暂停')
        WriteLog(ansible_log, process_info.stdout.decode())
    else:
        WriteLog(ansible_log, process_info.stdout.decode())
        print ('[error], 日志路径: {path}'.format(path=ansible_log))
        exit(1)


def Start(hosts,vars):
    exec = "cd ./ansible-es && ansible-playbook 3_start.yml -i {hosts} --extra-vars='@{vars}'".format(hosts=hosts, vars=vars)
    print ("[info], 执行命令: ", exec)
    process_info = subprocess.run(args=exec, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if process_info.returncode == 0:
        print ('[info], 已卸载')
        WriteLog(ansible_log, process_info.stdout.decode())
    else:
        WriteLog(ansible_log, process_info.stdout.decode())
        print ('[error], 日志路径: {path}'.format(path=ansible_log))
        exit(1)


def SuccessInfo(dict_info):
    server_infos = []
    for i in ALL_IP:
        server_info = {
        "service_name":"elasticsearch",
        "service_ip":i,
        "protocol":"tcp",
        "port":9200,
        "service_desc":"elasticsearch node"
        }
        server_infos.append(server_info)

    success_info = {
    "cluster_name":dict_info["cluster_name"],
    "serviceInfos":server_infos
    }
    return json.dumps(success_info)


def WriteLog(log_path, content):
    with open (log_path, 'w') as f:
        f.write(content)


def StringToList(dict):
    if 'es_initial_master_nodes' in dict:
        master_nodes = dict['es_initial_master_nodes']
        dict.update({'es_initial_master_nodes':master_nodes.split(',')})
    if 'es_discovery_seed_hosts' in dict:
        seed_hosts = dict['es_discovery_seed_hosts']
        dict.update({'es_discovery_seed_hosts':seed_hosts.split(',')})
    return dict


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        dict_info_str = sys.argv[2]
        # dict_info = sys.argv[2]
    except Exception as e:
        print(e)

    dict_info = json.loads(dict_info_str)
    host_info_lists = dict_info.pop('host_list')
    temp_dir = dict_info['temp_dir']
    dict_info = StringToList(dict_info)
    ansible_host_content = ToAnsibleHostINI(host_info_lists)
    ansible_host_file_path = FilePath(temp_dir,'ansible_host.ini')
    es_vars_file_path = FilePath(temp_dir,"es_vars.json")
    ansible_log = FilePath(temp_dir,'process.log')
    success_info = SuccessInfo(dict_info)


    with open (ansible_host_file_path, 'w') as f:
        f.write(ansible_host_content)

    with open (es_vars_file_path, 'w') as f:
        json.dump(dict_info, f)

    if action == 'install':
        Install(ansible_host_file_path, es_vars_file_path,dict_info['product_type'])
    elif action == 'uninstall':
        Uninstall(ansible_host_file_path, es_vars_file_path)
    elif action == 'stop':
        Stop(ansible_host_file_path, es_vars_file_path)
    elif action =='start':
        Start(ansible_host_file_path, es_vars_file_path)
    else:
        print ('[error], 无匹配动作')
        exit(1)
