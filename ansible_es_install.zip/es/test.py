'''
Author: Athrun
Email: erythron@qq.com
Date: 2021-06-16 17:12:31
LastEditTime: 2021-06-17 10:12:07
description: now it is null
'''

import json

dict_info = {
    "cluster_name":"test"
}

ALL_IP = ["1","2"]

def SuccessInfo(dict):


    server_infos = []
    for i in ALL_IP:
        server_info = {
        "service_name":"elasticsearch",
        "service_ip":i,
        "protocol":"tcp",
        "port":9200,
        "service_desc":"elasticsearch node"
        }
        server_infos.append(server_info)

    success_info = {
    "cluster_name":dict["cluster_name"],
    "serverInfos":server_infos
    }
    print ('test')
    print (success_info)
    return json.dumps(success_info)


print("[info], ",SuccessInfo(dict_info))